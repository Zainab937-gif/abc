---
layout: single
title: "Contact"
permalink: /contact/
author_profile: true
---

## Get In Touch

I'm open to **internships**, **collaborations**, and interesting **projects**.

Feel free to reach out through any of these:

- 📧 **Email:** zainab@email.com
- 💼 **LinkedIn:** linkedin.com/in/zainab
- 🐙 **GitHub:** github.com/zainab

---

*Based in Pakistan 🇵🇰*
