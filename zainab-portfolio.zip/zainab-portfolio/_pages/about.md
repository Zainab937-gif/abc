---
layout: single
title: "About Me"
permalink: /about/
author_profile: true
---

## Hi, I'm Zainab! 👋

I'm a **Computer Engineering** student from Pakistan, passionate about understanding how computers work from the ground up — from logic gates to full software systems.

## What I Do

- 💻 Write clean, efficient code in **C, C++, and Python**
- ⚡ Design digital circuits and embedded systems
- 🌐 Build web applications using Flask and SQL
- 🔧 Love solving complex algorithmic problems

## Skills

| Skill | Level |
|-------|-------|
| C / C++ | ⭐⭐⭐⭐⭐ |
| Python | ⭐⭐⭐⭐ |
| Digital Logic | ⭐⭐⭐⭐ |
| Embedded Systems | ⭐⭐⭐⭐ |
| Web Development | ⭐⭐⭐ |
| SQL / Databases | ⭐⭐⭐ |

## Education

**Bachelor of Computer Engineering**  
Currently Enrolled | Pakistan

## Currently Learning
- Computer Architecture
- Operating Systems
- Data Structures & Algorithms
