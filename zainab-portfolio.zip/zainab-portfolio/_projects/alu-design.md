---
title: "4-bit ALU Design"
excerpt: "Designed and simulated a full Arithmetic Logic Unit using Logisim with complete gate-level implementation."
header:
  teaser: /assets/images/alu.jpg
tags:
  - Logisim
  - Digital Logic
  - VHDL
---

## Overview

A complete **4-bit Arithmetic Logic Unit (ALU)** designed and simulated in Logisim with full gate-level implementation, truth tables, and timing diagrams.

## Features

- Supports ADD, SUB, AND, OR, XOR, NOT operations
- Carry-in and Carry-out flags
- Zero flag detection
- Full gate-level implementation

## Tech Stack

- **Tool:** Logisim
- **Language:** VHDL
- **Concepts:** Boolean Algebra, Combinational Circuits, Flip-Flops

## What I Learned

This project solidified my understanding of digital logic design and how hardware computes at the lowest level.
