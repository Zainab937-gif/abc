---
title: "Mini Compiler"
excerpt: "Built a lexer, parser, and code generator for a custom programming language."
header:
  teaser: /assets/images/compiler.jpg
tags:
  - C++
  - Compiler Design
---

## Overview

A **mini compiler** built from scratch for a custom programming language as part of compiler design coursework. Includes lexical analysis, parsing, and code generation phases.

## Features

- Lexer for tokenizing source code
- Recursive descent parser
- Symbol table management
- Basic error handling and reporting

## Tech Stack

- **Language:** C++
- **Concepts:** Automata Theory, Context-Free Grammars, Parse Trees

## What I Learned

This project deepened my understanding of how programming languages work under the hood and strengthened my C++ skills significantly.
