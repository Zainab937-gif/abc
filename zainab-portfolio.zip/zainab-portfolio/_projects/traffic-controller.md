---
title: "Smart Traffic Controller"
excerpt: "Microcontroller-based adaptive traffic system using IR sensors and real-time signal logic."
header:
  teaser: /assets/images/traffic.jpg
tags:
  - Embedded C
  - Arduino
  - IoT
---

## Overview

A **microcontroller-based adaptive traffic control system** that uses IR sensors to detect vehicle density and automatically adjusts signal timing to reduce congestion.

## Features

- Real-time vehicle detection using IR sensors
- Adaptive signal timing based on traffic density
- Emergency vehicle override mode
- Low power consumption design

## Tech Stack

- **Language:** Embedded C
- **Hardware:** Arduino Uno, IR Sensors, LEDs
- **Concepts:** Digital I/O, Interrupts, Timers

## What I Learned

Working on this project gave me hands-on experience with microcontroller programming, hardware interfacing, and real-time systems design.
