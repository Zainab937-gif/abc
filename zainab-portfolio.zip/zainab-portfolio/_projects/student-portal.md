---
title: "Student Portal"
excerpt: "Full-stack web application for managing student records, timetables, and grades."
header:
  teaser: /assets/images/portal.jpg
tags:
  - Python
  - Flask
  - MySQL
---

## Overview

A **full-stack web application** for managing student records, timetables, grade tracking, and attendance — built with Python and Flask.

## Features

- Student login and authentication
- Grade and attendance tracking
- Timetable management
- Admin dashboard for teachers
- Responsive UI

## Tech Stack

- **Backend:** Python, Flask
- **Database:** MySQL
- **Frontend:** HTML, CSS, Bootstrap

## What I Learned

This project gave me full-stack development experience and taught me how to design relational databases and build REST APIs.
